export default function Home() {
  return (
    <main className="max-w-2xl mx-auto px-4 py-10 font-sans">
      <h1 className="text-3xl font-bold mb-4">دندانپزشکی برای همه</h1>
      <p className="text-gray-700 mb-6">
        اگه دندون درد داری و به دندونپزشکت دسترسی نداری، با من باش تا بهت بگم چیکار باید بکنی.
      </p>
      <a href="/posts" className="text-blue-600 underline">مشاهده همه مقالات</a>
    </main>
  );
}