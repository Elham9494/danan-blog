import Link from 'next/link';
import fs from 'fs';
import path from 'path';

export async function getStaticProps() {
  const files = fs.readdirSync(path.join('posts'));
  const posts = files.map((filename) => {
    const slug = filename.replace('.md', '');
    return { slug };
  });
  return { props: { posts } };
}

export default function Posts({ posts }) {
  return (
    <main className="max-w-2xl mx-auto px-4 py-10 font-sans">
      <h1 className="text-2xl font-bold mb-6">مقالات</h1>
      <ul className="space-y-3">
        {posts.map(({ slug }) => (
          <li key={slug}>
            <Link href={`/posts/${slug}`} className="text-blue-600 underline">
              {slug.replace(/-/g, ' ')}
            </Link>
          </li>
        ))}
      </ul>
    </main>
  );
}