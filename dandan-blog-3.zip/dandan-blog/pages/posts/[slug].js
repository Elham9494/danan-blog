import fs from 'fs';
import path from 'path';
import matter from 'gray-matter';
import { marked } from 'marked';

export async function getStaticPaths() {
  const files = fs.readdirSync(path.join('posts'));
  const paths = files.map((filename) => ({
    params: { slug: filename.replace('.md', '') },
  }));
  return { paths, fallback: false };
}

export async function getStaticProps({ params: { slug } }) {
  const markdownWithMeta = fs.readFileSync(path.join('posts', slug + '.md'), 'utf-8');
  const { data, content } = matter(markdownWithMeta);
  return {
    props: {
      frontmatter: data,
      content,
    },
  };
}

export default function PostPage({ frontmatter, content }) {
  return (
    <main className="max-w-2xl mx-auto px-4 py-10 font-sans">
      <h1 className="text-2xl font-bold mb-4">{frontmatter.title}</h1>
      <article className="prose prose-sm" dangerouslySetInnerHTML={{ __html: marked(content) }} />
    </main>
  );
}